﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
             long fact = 1;
            Console.WriteLine("Enter an integer: ");
            String s = Console.ReadLine();
            int n=0;
             int.TryParse(s,out n); ;

            // shows error if the user enters a negative integer
            if (n < 0)
                Console.WriteLine("Error! Factorial of a negative number doesn't exist.");
            else
            {
                for (int i = 1; i <= n; ++i)
                {
                    fact *= i;
                }
                Console.WriteLine(String.Format("Factorial of {0} = {1}", n, fact));
            }

            Console.Read();
        }
    }
}
